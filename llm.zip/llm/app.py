import streamlit as st
from llm.cache import init_cache_db
from llm.utils import generate_response

st.title("🏦 BDI (Banco de Dados Intelligence)")

# Inicializa o banco de cache (se necessário)
init_cache_db()

with st.form("query_form"):
    user_input = st.text_area("Digite sua pergunta:", "Qual foi o último valor do IPCA em Recife?")
    submitted = st.form_submit_button("Consultar")

    if submitted:
        response = generate_response(user_input)
        st.markdown(response)
