import os
from dotenv import load_dotenv

# Carrega as configurações do arquivo .env
load_dotenv()

# Caminhos do banco de dados e do cache
DB_PATH = os.getenv("DB_PATH", "banco_padrao.db")
CACHE_DB_PATH = os.getenv("CACHE_DB_PATH", "cache_respostas.db")

# Caminho do modelo
MODEL_PATH = os.getenv(
    "MODEL_PATH",
)

